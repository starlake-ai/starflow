#
# Copyright © 2025 Starlake AI (https://starlake.ai)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from typing import List, Optional, Union

from ai.starlake.dagster import StarlakeDagsterJob, StarlakeDagsterUtils, DagsterLogicalDatetimeConfig

from ai.starlake.dataset import StarlakeDataset

from ai.starlake.job import StarlakePreLoadStrategy, StarlakeSparkConfig, StarlakeExecutionEnvironment, TaskType

from dagster import Failure, Output, AssetMaterialization, AssetKey, Out, op, RetryPolicy, OpExecutionContext

from dagster._core.definitions import NodeDefinition

from dagster_shell import execute_shell_command

class StarlakeDagsterShellJob(StarlakeDagsterJob):

    def __init__(self, filename: str=None, module_name: str=None, pre_load_strategy: Union[StarlakePreLoadStrategy, str, None]=None, options: dict=None, **kwargs) -> None:
        super().__init__(filename=filename, module_name=module_name, pre_load_strategy=pre_load_strategy, options=options, **kwargs)

    @classmethod
    def sl_execution_environment(cls) -> Union[StarlakeExecutionEnvironment, str]:
        """Returns the execution environment to use.

        Returns:
            StarlakeExecutionEnvironment: The execution environment to use.
        """
        return StarlakeExecutionEnvironment.SHELL

    def sl_job(self, task_id: str, arguments: list, spark_config: StarlakeSparkConfig=None, dataset: Optional[Union[StarlakeDataset, str]]= None, task_type: Optional[TaskType] = None, **kwargs) -> NodeDefinition:
        """Overrides IStarlakeJob.sl_job()
        Generate the Dagster node that will run the starlake command.

        Args:
            task_id (str): The required task id.
            arguments (list): The required arguments of the starlake command to run.
            spark_config (Optional[StarlakeSparkConfig], optional): The optional spark configuration. Defaults to None.
            dataset (Optional[Union[StarlakeDataset, str]], optional): The optional dataset to materialize. Defaults to None.
            task_type (Optional[TaskType], optional): The optional task type. Defaults to None.

        Returns:
            OpDefinition: The Dagster node.
        """
        found = False

        import os
        env = os.environ.copy() # Copy the current environment variables
        env.update(self.sl_env_vars.copy()) # Copy the current sl env variables

        for index, arg in enumerate(arguments):
            if arg == "--options" and arguments.__len__() > index + 1:
                opts = arguments[index+1]
                if opts.strip().__len__() > 0:
                    temp = self.sl_env_vars.copy() # Copy the current sl env variables
                    temp.update({
                        key: value
                        for opt in opts.split(",")
                        if "=" in opt  # Only process valid key=value pairs
                        for key, value in [opt.split("=")]
                    })
                    options = ",".join([f"{key}={value}" for i, (key, value) in enumerate(temp.items())])
                    for opt in opts.split(","):
                        if "=" not in opt:
                            options += f",{opt}"
                else:
                    options = ",".join([f"{key}={value}" for i, (key, value) in enumerate(self.sl_env_vars.items())])
                arguments[index+1] = options
                found = True
                break

        if not found:
            arguments.append("--options")
            arguments.append(",".join([f"{key}={value}" for key, value in self.sl_env_vars.items()]))

        sl_command = self.__class__.get_context_var("SL_STARLAKE_PATH", "starlake", self.options)

        if not task_type and len(arguments) > 0:
            task_type = TaskType.from_str(arguments[0])
        transform = task_type == TaskType.TRANSFORM
        params = kwargs.get('params', dict())

        # static sl_options sections to publish on the materialization (see
        # DagsterLogicalDatetimeConfig.sl_options for the runtime counterpart)
        extra = kwargs.pop("extra", None)

        # story 6.2 (issue #86) — sensor mode: popped BEFORE the outs/RetryPolicy
        # computation and captured by the op closure below (story 6.7 moved the
        # strict resolution + wall-clock loop to the shared StarlakeDagsterJob
        # seams _sl_resolve_pre_load_poke/_sl_pre_load_poke_loop)
        pre_load_poke = self.__class__._sl_resolve_pre_load_poke(kwargs)

        # story 6.12 (issue #122) — not-ready sentinel: popped BEFORE the
        # outs/RetryPolicy computation, captured by the op closure below;
        # shell consumes local paths only (engine-aware scheme gate)
        sentinel_path = self.__class__._sl_resolve_sentinel(kwargs, ('', 'file'), 'shell')
        if task_type != TaskType.PRELOAD:
            sentinel_path = None

        assets: List[AssetKey] = kwargs.get("assets", [])

        ins=kwargs.get("ins", {})

        out:str=kwargs.get("out", "result")
        failure:str=kwargs.get("failure", None)
        skip_or_start = bool(kwargs.get("skip_or_start", False))
        outs=kwargs.get("outs", {out: Out(str, is_required=not skip_or_start and failure is None)})
        if failure:
            outs.update({failure: Out(str, is_required=False)})

        max_retries = int(kwargs.get("retries", self.retries))
        if max_retries > 0:
            retry_policy = RetryPolicy(max_retries=max_retries, delay=self.retry_delay)
        else:
            retry_policy = None

        @op(
            name=task_id,
            ins=ins,
            out=outs,
            retry_policy=retry_policy,
        )
        def job(context: OpExecutionContext, config: DagsterLogicalDatetimeConfig, **kwargs):

            # per-attempt copy (issue #115): appending to the closure list
            # would make a RetryPolicy re-execution yield one duplicate
            # AssetMaterialization per prior attempt (and the list is the
            # caller's kwargs list, shared across graph rebuilds)
            attempt_assets: List[AssetKey] = list(assets)
            if dataset:
                attempt_assets.append(StarlakeDagsterUtils.get_asset(context, config, dataset, **kwargs))

            from ai.starlake.common import sl_timestamp_format
            logical_datetime: str = StarlakeDagsterUtils.get_logical_datetime(context, config).strftime(sl_timestamp_format)
            # read WITHOUT mutating (issue #111): `arguments` is the closure
            # list — a RetryPolicy re-execution of this op function would
            # otherwise pop the next element as the command
            command = arguments[0]
            if task_type is not None and (task_type == TaskType.LOAD or task_type == TaskType.TRANSFORM):
                tmp_arguments = ["--scheduledDate", f"\'{logical_datetime}\'"]
                command_with_arguments = [command] + tmp_arguments + arguments[1:]
            else:
                command_with_arguments = [command] + arguments[1:]

            if transform:
                opts = command_with_arguments[-1].split(",")
                transform_opts = StarlakeDagsterUtils.get_transform_options(context, config, params, **kwargs).split(',')
                opts.extend(transform_opts)
                # runtime sl_options carried by the run (sensor RunRequest or manual
                # launch) — appended last so they override the static ones (starlake
                # keeps the last occurrence of a duplicate key): precedence
                # static < 'all' < task-specific.
                runtime_options = StarlakeDagsterUtils.get_sl_options(context, config, task_id)
                if runtime_options:
                    opts.extend([f"{key}={value}" for key, value in runtime_options.items()])
                command_with_arguments[-1] = ",".join(opts)

            # double quotes so values containing spaces survive shell word splitting;
            # applied here, after the transform branch has split/merged the value on commas
            for i, arg in enumerate(command_with_arguments[:-1]):
                if arg == "--options":
                    command_with_arguments[i + 1] = f'"{command_with_arguments[i + 1]}"'
                    break

            if sentinel_path:
                # story 6.12 — run-time scope substitution over the per-attempt
                # vector (the --notReadySentinel value embeds the scope token)
                command_with_arguments = self.__class__._sl_sentinel_substitute_args(
                    command_with_arguments, context
                )
                # double-quote the sentinel value: this vector is joined into
                # ONE shell command (unlike the cloud list transports) and a
                # space-bearing prefix would word-split the argument (#51 —
                # same rule as the Airflow bash twin)
                for i, arg in enumerate(command_with_arguments[:-1]):
                    if arg == "--notReadySentinel":
                        command_with_arguments[i + 1] = f'"{command_with_arguments[i + 1]}"'
                        break

            command = sl_command + f" {' '.join(command_with_arguments or [])}"

            if config.dry_run:
                output, return_code = f"Starlake command {command} execution skipped due to dry run mode.", 0
                context.log.info(output)
            else:
                context.log.info(f"Executing Starlake command: {command}")

                def _run_command():
                    # Execute the shell command
                    return execute_shell_command(
                        shell_command=command,
                        output_logging="STREAM",
                        log=context.log,
                        cwd=self.sl_root,
                        env=env,
                        log_shell_command=True,
                    )

                if sentinel_path:
                    # story 6.12 — three-way verdict: non-zero exit is a REAL
                    # failure (fail fast — 'not ready' exits 0 in sentinel
                    # mode, so the skip_or_start swallow no longer applies);
                    # exit 0 + sentinel → consume → not ready; exit 0 → ready
                    def _run_and_check():
                        run_output, run_return_code = _run_command()
                        if run_return_code:
                            raise Failure(description=(
                                f"Starlake command {command} failed with exit "
                                f"code {run_return_code} — a real failure "
                                f"('not ready' exits 0 in sentinel mode): {run_output}"
                            ))
                        ready = self.__class__._sl_sentinel_ready(context, sentinel_path)
                        return run_output, run_return_code, ready

                    if pre_load_poke:
                        # poke again while the sentinel keeps signaling
                        # not-ready; the loop's deadline/soft_fail semantics
                        # are unchanged
                        poked = self.__class__._sl_pre_load_poke_loop(
                            context,
                            _run_and_check,
                            lambda result: result[2],
                            pre_load_poke,
                            command,
                        )
                        if poked is None:
                            return
                        output, return_code, _ = poked
                    else:
                        output, return_code, ready = _run_and_check()
                        if not ready:
                            context.log.info(
                                f"Starlake command {command}: files not ready "
                                f"(sentinel consumed) — skipping downstream tasks."
                            )
                            return
                elif pre_load_poke:
                    # story 6.2 — in-op wall-clock poke loop (shared seam since
                    # story 6.7); on soft-fail deadline the loop returns None →
                    # bare return (optional-output skip); the hard timeout
                    # Failure is raised inside the loop so the skip_or_start
                    # bare-return branch below cannot swallow it
                    poked = self.__class__._sl_pre_load_poke_loop(
                        context,
                        _run_command,
                        lambda result: not result[1],
                        pre_load_poke,
                        command,
                    )
                    if poked is None:
                        return
                    output, return_code = poked
                else:
                    output, return_code = _run_command()

            if return_code:
                value=f"Starlake command {command} execution failed with output: {output}"
                if retry_policy:
                    retry_count = context.retry_number
                    if retry_count < retry_policy.max_retries:
                        raise Failure(description=value)
                if failure:
                    yield Output(value=value, output_name=failure)
                elif skip_or_start:
                    context.log.info(f"Skipping Starlake command {command} execution due to skip_or_start flag.")
                    return
                else:
                    raise Failure(description=value)
            else:
                for asset in attempt_assets:
                    yield AssetMaterialization(asset_key=asset.path, description=kwargs.get("description", f"Starlake command {command} execution succeeded"))
                if dataset:
                    yield StarlakeDagsterUtils.get_materialization(context, config, dataset, extra=extra, **kwargs)

                yield Output(value=output, output_name=out)

        return job
